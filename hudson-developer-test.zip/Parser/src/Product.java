/**
 * Note on class structure:
 * The class is how would would expect, private instance variables accessed with public getters/setters in order to satisfy the OO principle of encapsulation.
 * 
 * The purpose of this class is to store the data associated with each product on the target website. 
 * The class is set up to be easily modified to expand the scope of the application, e.g. check stocks
**/

public class Product {
	
	private String product;
	private String image_url;
	private int quantity;
	private double price;
	
	public Product(String product, String image_url, int quantity, double price) {
		this.product = product;
		this.image_url = image_url;
		this.quantity = quantity;
		this.price = price;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getImage_url() {
		return image_url;
	}

	public void setImage_url(String image_url) {
		this.image_url = image_url;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	public String toString() {
		return this.product + ", " + this.image_url + ", " + String.valueOf(this.quantity) + ", " + String.valueOf(this.price);
	}

}
