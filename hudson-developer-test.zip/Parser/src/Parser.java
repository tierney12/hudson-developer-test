import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedList;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.util.List;

import org.json.simple.JSONObject;
import org.json.simple.JSONValue;  

/**
 * 
 * @author Sean Tierney
 * @date 7 April 2021
 *
 *
 * The purpose of this API is to parse a target store webpage and output a JSON file containing a list of products and associated metadata, meeting the requirements of the given specification
 * of the Hudson developer test. 
 *
 * Expected input: 1-2 arguments, the url of the target webpage and optionally the filename to output (defaults to 'output.json').
 * 
 * Imported modules: 
 *  - Jsoup, a module for parsing HTML
 *  - JSONObject, a module for creating out JSON formatted string for output to file
 */

public class Parser {

	public static void main(String args[]){
	
		if(args.length < 1 || args.length > 2) {
			System.out.print("Expected arguments: url [output filename]");
			return;
		}
		
		String url = args[0];
		String filename = "output.json";
		
		if(args.length == 2) {
			filename = args[1];
		}
			
		Document document; //the document object produced by parsing the HTML from the given url
		try {
			document = Jsoup.connect(url).get();
			
			Elements elements = document.getAllElements(); //the individual elements that make up the HTML 
			
			LinkedList<Product> products = new LinkedList<Product>(); //the products to output
			
			/**
			 * Note on implementation: while analysing the HTML of the target url, I noticed a typo in a class name of the tile that the 'garlic bread' 
			 *  product should be displayed in. Due to this typo the product isn't displayed in the same manner, so in order to produce a full list of products I
			 *  took advantage of the structure of the HTML and parsed through the different products by the 'product-details' subclass,
			 *  then retrieving the previous element in the document which stores the associated image which I require to satisfy the specification. 
			 *  If instead I were to parse by elements of the 'product-tile' class then the 'garlic bread' product would be omitted due to this typo.
			 *  
			 *  For each product defined in the HTML, I parse the associated fields and retrieve the metadata. Then instantiate a new product class to store the
			 *  data and add it to a linked list to be stored for output. Another approach would be to put the data straight into the JSON file, however taking an OO
			 *  approach allows for simpler extension/testing of the application, as well as separation of concerns. 
			 */
			
			
			for(Element element:elements) {
			
				if(element.className().contains("product-details")) {
					
					String product_img_url = "";
					String product_name = "";
					int product_quantity = 0;
					double product_price = 0;
					
					//gets the product image by retrieving the previous element in the document 
					Element image = elements.get(elements.indexOf(element) - 1);
					if(!image.attr("src").isEmpty()) {
						product_img_url = image.attr("src");
					}
					else if(!image.attr("alt").isEmpty()){
						product_img_url = image.attr("alt");
					}
					else{product_img_url = "";}
					
					product_name = element.getElementsByClass("product-name").text();
					
					//parse through the paragraph elements to retrieve the metadata
					Elements product_details = element.getElementsByClass("details");
					for(Element details:product_details) {
						Elements detail = details.getElementsByTag("p");
						for(Element d:detail) {
							if(d.text().contains("Quantity")) {
								product_quantity = Integer.parseInt(d.text().replaceAll("[^\\d.]", ""));
							}
							if(d.text().contains("Price")) {
								product_price = Double.parseDouble(d.text().replaceAll("[^\\d.]", ""));
							}
						}
						
					}
					
					Product product = new Product(product_name, product_img_url, product_quantity, product_price);
					products.add(product);
				}
				
			}
			//create the JSON formatted string of the product list
			String json = createJSON(products);
			
			//write to file and terminate the program
			if(writeToFile(json, filename)) {
				print("Application terminated with no errors");
				return;
			}

		} catch (IOException e) {
			e.printStackTrace();
			print("An error occured");
		}
		
	}
	
	@SuppressWarnings("unchecked")
	//takes a list of products and produces a JSON formatted string to meet the specification of the test
	//I have defined the data types of the instance variables of the Product class, hence we do not need to catch errors relating to producing the JSON formated String

	public static String createJSON(List<Product> products) {
		List<JSONObject> json_list = new LinkedList<JSONObject>();  
		
		for(Product product:products) {
			
			JSONObject outer = new JSONObject();
			JSONObject inner = new JSONObject(); 
			
			inner.put("price", product.getPrice());
			inner.put("quantity", product.getQuantity());  
			inner.put("image_url", product.getImage_url()); 
			
			
			outer.put("metadata", inner);
			outer.put("Product",product.getProduct()); 
			
			json_list.add(outer);
			
		}
		
		return JSONValue.toJSONString(json_list);
	}
	
	
	//takes a JSON formatted string and writes it to the given filename
	public static boolean writeToFile(String text, String filename) {
		try {
            FileWriter file = new FileWriter(filename);
            file.write(text);
            file.close();
            return true;
 
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
		
	}

	//helper print function for inline testing of parameters.
	public static void print(String string) {
		System.out.println(string);
	}

}
